# Changelog

## v6.02

- Consolidated runtime mapping storage on `mappings.tsv`.
- Added legacy `mapping.tsv` migration.
- Added canonical configuration validation.
- Improved initialization output.
- Added persisted reconciliation records.
- Added JSON diff output.
- Added dry-run sync behavior.
- Added release-pinned installer.
- Improved Termux support.
