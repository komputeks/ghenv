# ghsync v6.02

A Termux-friendly GitHub configuration synchronization CLI.

## Install

```bash
curl -fsSL https://raw.githubusercontent.com/komputeks/ghsync/v6.02/install.sh | bash
```

Then:

```bash
ghsync init
```

## Termux development test

Keep the repository under `$HOME`, not `/storage/emulated/0`, because Android shared storage is commonly mounted `noexec`.

```bash
chmod +x ghsync install.sh
./ghsync --version
./ghsync doctor --deep
./ghsync init --repo OWNER/REPO
```

## v6.02 changes

- Canonical `mappings.tsv`; automatic migration from legacy `mapping.tsv`.
- Consistent configuration layout.
- Mapping generation validates its output.
- Reconciliation records are persisted.
- `--dry-run`, `--json`, and `--yes` are recognized globally.
- Termux-safe installer using `$HOME/bin`.
- SHA-256 verification.
- Release is pinned to `v6.02`.
- No dependency on earlier v5.x function layers.

## Configuration

Default:

```text
~/.config/ghsync/
├── repo
├── mappings.tsv
├── state.tsv
├── reconciliations/
└── vault/
    └── vault.enc
```

The vault key is currently stored as `~/.config/ghsync/.vault.key` for compatibility with the v6 development vault. Passphrase-derived key storage is planned for the security-hardening release.

## Commands

```text
ghsync init
ghsync status
ghsync diff
ghsync sync [--yes]
ghsync list [secrets|variables|all]
ghsync repo OWNER/REPO
ghsync env NAME
ghsync vault init
ghsync map list|validate
ghsync state
ghsync doctor [--deep]
ghsync completion
```

## Release

The immutable release tag is `v6.02`. The installer downloads only from that tag and verifies `checksums.txt`.
