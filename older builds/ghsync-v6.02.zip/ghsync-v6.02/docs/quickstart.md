# Quickstart

1. Authenticate:

```bash
gh auth login
```

2. Install:

```bash
curl -fsSL https://raw.githubusercontent.com/komputeks/ghsync/v6.02/install.sh | bash
```

3. Initialize:

```bash
ghsync init
```

4. Inspect:

```bash
ghsync status
ghsync map list
ghsync map validate
ghsync diff
```

5. Apply:

```bash
ghsync sync
```
