# Release process

```bash
git add .
git commit -m "release: ghsync v6.02"
git tag -a v6.02 -m "ghsync v6.02"
git push origin main
git push origin v6.02
```

The GitHub Actions workflow validates shell syntax, creates `checksums.txt`, and publishes the tagged release.
