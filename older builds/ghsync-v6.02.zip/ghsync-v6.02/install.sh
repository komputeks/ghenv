#!/usr/bin/env bash
set -Eeuo pipefail
NAME="ghsync"
VERSION="6.02"
OWNER_REPO="komputeks/ghsync"
BASE_URL="https://raw.githubusercontent.com/${OWNER_REPO}/v${VERSION}"
INSTALL_DIR="${GH_SYNC_INSTALL_DIR:-$HOME/bin}"
TARGET="$INSTALL_DIR/ghsync"

die(){ echo "ERROR: $*" >&2; exit 1; }
command -v curl >/dev/null 2>&1 || die "curl is required"
command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"
mkdir -p "$INSTALL_DIR"
tmp="$(mktemp)"
trap 'rm -f "$tmp" "$tmp.sha256"' EXIT

echo "Installing ghsync v$VERSION..."
curl -fsSL "$BASE_URL/ghsync" -o "$tmp"
curl -fsSL "$BASE_URL/checksums.txt" -o "$tmp.sha256"

expected="$(awk '$2=="ghsync"{print $1}' "$tmp.sha256" | head -n1)"
[[ -n "$expected" ]] || die "checksum for ghsync not found"
actual="$(sha256sum "$tmp" | awk '{print $1}')"
[[ "$expected" == "$actual" ]] || die "checksum verification failed"

install -m 700 "$tmp" "$TARGET" 2>/dev/null || { cp "$tmp" "$TARGET"; chmod 700 "$TARGET"; }

case ":$PATH:" in *":$INSTALL_DIR:"*) ;; *) echo "NOTE: add $INSTALL_DIR to PATH: export PATH=\"$INSTALL_DIR:\$PATH\"";; esac
echo
echo "ghsync v$VERSION installed successfully."
echo "Run:"
echo "    ghsync init"
