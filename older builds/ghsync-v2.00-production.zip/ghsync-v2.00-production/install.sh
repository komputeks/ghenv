#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t';umask 077
VERSION=2.00; OWNER_REPO=komputeks/ghsyncs; BASE_URL="https://raw.githubusercontent.com/$OWNER_REPO/v$VERSION"
die(){ echo "ERROR: $*" >&2;exit 1; };command -v curl >/dev/null||die 'curl required';command -v sha256sum >/dev/null||die 'sha256sum required'
if [[ -n "${PREFIX:-}"&&-d "$PREFIX/bin" ]];then DIR="${GH_SYNC_INSTALL_DIR:-$PREFIX/bin}";PLATFORM=Termux;else DIR="${GH_SYNC_INSTALL_DIR:-$HOME/.local/bin}";PLATFORM=Unix;fi
mkdir -p "$DIR";TARGET="$DIR/ghsync";a="$(mktemp)";b="$(mktemp)";trap 'rm -f "$a" "$b"' EXIT
echo "Installing ghsync v$VERSION ($PLATFORM)...";curl -fsSL "$BASE_URL/ghsync" -o "$a"||die download;curl -fsSL "$BASE_URL/checksums.txt" -o "$b"||die checksums
exp="$(awk '$2=="ghsync"{print $1}' "$b"|head -n1)";act="$(sha256sum "$a"|awk '{print $1}')";[[ "$exp" == "$act" ]]||die 'checksum verification failed';install -m 700 "$a" "$TARGET" 2>/dev/null||{ cp "$a" "$TARGET";chmod 700 "$TARGET";};"$TARGET" --version >/dev/null||die 'installed executable failed self-test'
echo;echo "✓ ghsync v$VERSION installed successfully.";echo "✓ checksum verified";echo "✓ executable installed at $TARGET";echo;echo 'Run from anywhere:';echo '  ghsync --version';echo '  ghsync doctor';echo '  ghsync init'
