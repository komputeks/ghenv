# ghsync v2.00

Production-oriented GitHub configuration synchronization CLI.

## Install

```bash
curl -fsSL https://raw.githubusercontent.com/komputeks/ghsyncs/v2.00/install.sh | bash
```

Termux installs into `$PREFIX/bin`, making `ghsync` available from any directory.

## First run

```bash
gh auth login
ghsync init
```

Or specify a repository:

```bash
ghsync init --repo OWNER/REPO
```

## Workflow

```bash
ghsync status
ghsync diff
ghsync sync
ghsync sync --yes
ghsync sync --dry-run
ghsync doctor --deep
```

## Security

GitHub Actions secret plaintext is not retrievable through normal GitHub secret APIs. ghsync treats secrets as local-source-of-truth values and pushes them to GitHub. Variables can be synchronized bidirectionally. Never commit `~/.config/ghsync`.
