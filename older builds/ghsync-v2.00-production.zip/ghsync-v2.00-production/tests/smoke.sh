#!/usr/bin/env bash
set -Eeuo pipefail
R="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."&&pwd)"
bash -n "$R/ghsync"
bash -n "$R/install.sh"
[[ "$(bash "$R/ghsync" --version)" == 'ghsync v2.00' ]]
bash "$R/ghsync" help >/dev/null
echo 'smoke tests passed'
