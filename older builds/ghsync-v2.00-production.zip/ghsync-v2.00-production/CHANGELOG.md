# Changelog

## v2.00
- Complete coherent rewrite as a single production CLI.
- Termux global installation via `$PREFIX/bin`.
- Pinned installer and checksum verification.
- Encrypted local vault with integrity protection.
- Repository and environment variable discovery.
- Local-source-of-truth secret synchronization.
- Reconciliation, dry-run, approval, JSON output, and state events.
- Doctor and Bash-friendly CLI.

GitHub does not return Actions secret plaintext. ghsync therefore never pretends remote secrets can be pulled.
