# Installation

Termux: `curl -fsSL https://raw.githubusercontent.com/komputeks/ghsyncs/v2.00/install.sh | bash`

The installer detects `$PREFIX` and installs to `$PREFIX/bin`.
