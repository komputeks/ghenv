# Architecture

GitHub CLI -> discovery -> mappings -> encrypted vault -> reconciliation -> approval -> GitHub -> state log.
