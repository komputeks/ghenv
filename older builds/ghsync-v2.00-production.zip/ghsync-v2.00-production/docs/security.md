# Security

Remote GitHub Actions secret plaintext is not available. Secret mappings are therefore local-source-of-truth and push-only. Variables may be read and synchronized. The local vault uses encrypted records with integrity protection and strict file permissions.
