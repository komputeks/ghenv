# Releases

Release tags are immutable installation targets. `install.sh` and `checksums.txt` are served from the matching tag.
