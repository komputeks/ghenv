# Commands

Use `ghsync help`. Common commands: `init`, `status`, `diff`, `sync`, `list`, `get`, `set`, `delete`, `vault`, `map`, `state`, `doctor`.
