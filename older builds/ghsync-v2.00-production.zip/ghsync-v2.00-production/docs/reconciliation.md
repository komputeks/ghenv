# Reconciliation

`CREATE` and `UPDATE` are actionable. `SYNCED` is equal. `CONFLICT` blocks automatic sync. `REMOTE_ONLY` means a remote object has no local value. `MISSING_LOCAL` means neither side has a local value.
