package github
import "testing"
func TestEncryptUsesKeyLengthValidation(t *testing.T){_,e:=enc(PublicKey{Key:"AQID"},"x");if e==nil{t.Fatal("expected invalid key error")}}
