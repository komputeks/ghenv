package github

import (
 "encoding/json"
 "net/http"
 "net/http/httptest"
 "testing"
)

func TestSetVariableCreatesWithPostAfterPatch404(t *testing.T) {
 var patchSeen, postSeen bool
 ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request) {
  switch r.Method {
  case http.MethodPatch:
   patchSeen=true
   if r.URL.Path!="/repos/o/r/actions/variables/TEST" {t.Fatalf("patch path %s",r.URL.Path)}
   http.NotFound(w,r); return
  case http.MethodPost:
   postSeen=true
   if r.URL.Path!="/repos/o/r/actions/variables" {t.Fatalf("post path %s",r.URL.Path)}
   var body map[string]string
   if e:=json.NewDecoder(r.Body).Decode(&body);e!=nil{t.Fatal(e)}
   if body["name"]!="TEST"||body["value"]!="hello"{t.Fatalf("body %#v",body)}
   w.WriteHeader(http.StatusNoContent); return
  default:
   t.Fatalf("unexpected %s %s",r.Method,r.URL.Path)
  }
 }))
 defer ts.Close()
 c:=New("token"); c.BaseURL=ts.URL
 if e:=c.SetVariable("o","r","TEST","hello","actions","");e!=nil{t.Fatal(e)}
 if !patchSeen||!postSeen{t.Fatalf("patch=%v post=%v",patchSeen,postSeen)}
}

func TestSetVariableUpdatesWithPatch(t *testing.T) {
 var patchSeen, postSeen bool
 ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request) {
  if r.Method == http.MethodPatch {
   patchSeen=true
   if r.URL.Path!="/repos/o/r/actions/variables/TEST" {t.Fatalf("patch path %s",r.URL.Path)}
   w.WriteHeader(http.StatusNoContent); return
  }
  if r.Method == http.MethodPost {postSeen=true}
  t.Fatalf("unexpected %s %s",r.Method,r.URL.Path)
 }))
 defer ts.Close()
 c:=New("token"); c.BaseURL=ts.URL
 if e:=c.SetVariable("o","r","TEST","hello","actions","");e!=nil{t.Fatal(e)}
 if !patchSeen||postSeen{t.Fatalf("patch=%v post=%v",patchSeen,postSeen)}
}
