package github

import ("bytes";"encoding/base64";"encoding/json";"fmt";"io";"net/http";"net/url";"strings";"time";"golang.org/x/crypto/nacl/box")

type Client struct{Token,BaseURL string;HTTP *http.Client}
type PublicKey struct{KeyID string `json:"key_id"`;Key string `json:"key"`}
type ListResponse struct{Secrets []struct{Name string `json:"name"`} `json:"secrets"`;Variables []struct{Name string `json:"name"`; Value string `json:"value"`} `json:"variables"`}
func New(t string)*Client{return &Client{t,"https://api.github.com",&http.Client{Timeout:30*time.Second}}}
func(c *Client) req(m,p string,b,out any)error{var r io.Reader;if b!=nil{x,e:=json.Marshal(b);if e!=nil{return e};r=bytes.NewReader(x)}
 q,e:=http.NewRequest(m,strings.TrimRight(c.BaseURL,"/")+p,r);if e!=nil{return e};q.Header.Set("Accept","application/vnd.github+json");q.Header.Set("X-GitHub-Api-Version","2022-11-28");if c.Token!=""{q.Header.Set("Authorization","Bearer "+c.Token)};if b!=nil{q.Header.Set("Content-Type","application/json")}
 z,e:=c.HTTP.Do(q);if e!=nil{return e};defer z.Body.Close();d,_:=io.ReadAll(z.Body);if z.StatusCode<200||z.StatusCode>=300{return fmt.Errorf("GitHub API %s: %s: %s",z.Status,m,strings.TrimSpace(string(d)))};if out!=nil&&len(d)>0{return json.Unmarshal(d,out)};return nil}
func(c *Client) Env(owner,repo,name string,create bool)error{p:=fmt.Sprintf("/repos/%s/%s/environments/%s",owner,repo,url.PathEscape(name));if c.req(http.MethodGet,p,nil,nil)==nil{return nil};if !create{return fmt.Errorf("environment %q does not exist",name)};return c.req(http.MethodPut,p,map[string]any{},nil)}
func key(c *Client,p string)(PublicKey,error){var k PublicKey;e:=c.req(http.MethodGet,p,nil,&k);return k,e}
func enc(k PublicKey,v string)(string,error){b,e:=base64.StdEncoding.DecodeString(k.Key);if e!=nil{return "",e};if len(b)!=32{return "",fmt.Errorf("invalid public key length")};var r [32]byte;copy(r[:],b);x,e:=box.SealAnonymous(nil,[]byte(v),&r,nil);if e!=nil{return "",e};return base64.StdEncoding.EncodeToString(x),nil}
func(c *Client) target(owner,repo,app,env string)(string,string,string,string){base:=fmt.Sprintf("/repos/%s/%s",owner,repo);if env!=""{base+="/environments/"+url.PathEscape(env);return base+"/secrets/public-key",base+"/secrets/%s",base+"/secrets",base+"/variables/%s"};if app==""{app="actions"};return base+"/"+app+"/secrets/public-key",base+"/"+app+"/secrets/%s",base+"/"+app+"/secrets",base+"/"+app+"/variables/%s"}
func(c *Client) SetSecret(owner,repo,name,value,app,env string)error{k,p,_,_:=c.target(owner,repo,app,env);x,e:=key(c,k);if e!=nil{return e};v,e:=enc(x,value);if e!=nil{return e};return c.req(http.MethodPut,fmt.Sprintf(p,url.PathEscape(name)),map[string]string{"encrypted_value":v,"key_id":x.KeyID},nil)}
func(c *Client) SetVariable(owner,repo,name,value,app,env string) error {
 _,_,_,p:=c.target(owner,repo,app,env)
 item:=fmt.Sprintf(p,url.PathEscape(name))
 // Repository/environment variables use POST to create and PATCH to update.
 // Try PATCH first; if the variable does not exist, GitHub returns 404 and
 // we create it with POST at the collection endpoint.
 if e:=c.req(http.MethodPatch,item,map[string]string{"name":name,"value":value},nil); e==nil {return nil}
 collection:=strings.TrimSuffix(p,"%s"); collection=strings.TrimSuffix(collection,"/")
 return c.req(http.MethodPost,collection,map[string]string{"name":name,"value":value},nil)
}
func(c *Client) ListSecrets(owner,repo,app,env string)([]string,error){_,_,p,_:=c.target(owner,repo,app,env);var x ListResponse;if e:=c.req(http.MethodGet,p,nil,&x);e!=nil{return nil,e};o:=[]string{};for _,v:=range x.Secrets{o=append(o,v.Name)};return o,nil}
func(c *Client) ListVariables(owner,repo,app,env string)([][2]string,error){_,_,_,p:=c.target(owner,repo,app,env);p=strings.TrimSuffix(p,"%s");var x ListResponse;if e:=c.req(http.MethodGet,p,nil,&x);e!=nil{return nil,e};o:=[][2]string{};for _,v:=range x.Variables{o=append(o,[2]string{v.Name,v.Value})};return o,nil}
func(c *Client) SetOrgSecret(org,name,value,app string)error{if app==""{app="actions"};k:=fmt.Sprintf("/orgs/%s/%s/secrets/public-key",org,app);p:=fmt.Sprintf("/orgs/%s/%s/secrets/%s",org,app,url.PathEscape(name));x,e:=key(c,k);if e!=nil{return e};v,e:=enc(x,value);if e!=nil{return e};return c.req(http.MethodPut,p,map[string]any{"encrypted_value":v,"key_id":x.KeyID,"visibility":"all"},nil)}
func(c *Client) SetOrgVariable(org,name,value,app string)error{if app==""{app="actions"};p:=fmt.Sprintf("/orgs/%s/%s/variables/%s",org,app,url.PathEscape(name));return c.req(http.MethodPost,p,map[string]string{"name":name,"value":value,"visibility":"all"},nil)}
