package cli

import("fmt";"os";"strings";"github.com/komputeks/goenv/internal/dotenv";gh "github.com/komputeks/goenv/internal/github")
const version="0.2.4"
type Opt struct{repo,org,file,env,app,typ,token string;force,dry bool}
func Run(){if len(os.Args)<2||os.Args[1]=="help"||os.Args[1]=="--help"{usage();return};if os.Args[1]=="version"{fmt.Println("goenv v"+version);return};if os.Args[1]!="push"&&os.Args[1]!="pull"{die("unknown command: "+os.Args[1])};o:=parse(os.Args[2:]);validate(o);if os.Args[1]=="push"{push(o)}else{pull(o)}}
func parse(a []string)Opt{o:=Opt{typ:"secret",token:os.Getenv("GITHUB_TOKEN")};for i:=0;i<len(a);i++{switch a[i]{case"--repo","-R":i++;need(a,i,"--repo");o.repo=a[i];case"--org":i++;need(a,i,"--org");o.org=a[i];case"--file","-f":i++;need(a,i,"--file");o.file=a[i];case"--env","-e":i++;need(a,i,"--env");o.env=a[i];case"--app","-a":i++;need(a,i,"--app");o.app=a[i];case"--type","-t":i++;need(a,i,"--type");o.typ=a[i];case"--token":i++;need(a,i,"--token");o.token=a[i];case"--force":o.force=true;case"--dry-run":o.dry=true;default:die("unknown option: "+a[i])}};return o}
func validate(o Opt){if(o.repo==""== (o.org=="")){die("specify exactly one of --repo or --org")};if o.file==""{die("missing --file")};if o.typ!="secret"&&o.typ!="variable"{die("invalid --type: "+o.typ)};switch o.app{case"","actions","agents","codespaces","dependabot":default:die("invalid --app: "+o.app)};if o.env!=""&&(o.org!=""||o.app!=""){die("--env requires --repo and cannot be combined with --app")};if(o.app=="codespaces"||o.app=="dependabot")&&o.typ=="variable"{die(o.app+" does not support variables")};if o.token==""&&!o.dry{die("GITHUB_TOKEN or --token is required")};if _,e:=os.Stat(o.file);e==nil&&!o.force&&!o.dry{die("file already exists: "+o.file+" (use --force)")}}
func push(o Opt){if _,e:=os.Stat(o.file);e!=nil{die("file not found: "+o.file)};x,e:=dotenv.ParseFile(o.file);if e!=nil{die(e.Error())};if o.dry{fmt.Printf("Dry run: %d %s(s); no changes made.\n",len(x),o.typ);return};c:=gh.New(o.token);owner,repo:="","";if o.repo!=""{owner,repo=split(o.repo)};if o.env!=""{if e:=c.Env(owner,repo,o.env,true);e!=nil{die(e.Error())}};for _,v:=range x{var e error;if o.typ=="secret"{if o.org!=""{e=c.SetOrgSecret(o.org,v.Name,v.Value,o.app)}else{e=c.SetSecret(owner,repo,v.Name,v.Value,o.app,o.env)}}else{if o.org!=""{e=c.SetOrgVariable(o.org,v.Name,v.Value,o.app)}else{e=c.SetVariable(owner,repo,v.Name,v.Value,o.app,o.env)}};if e!=nil{die(v.Name+": "+e.Error())};fmt.Println("✓",v.Name)};fmt.Println("Done.")}
func pull(o Opt){if o.dry{fmt.Printf("Dry run: would pull %s to %s\n",o.typ,o.file);return};if _,e:=os.Stat(o.file);e==nil&&!o.force{die("file already exists: "+o.file+" (use --force)")};c:=gh.New(o.token);owner,repo:="","";if o.repo!=""{owner,repo=split(o.repo)};if o.env!=""{if e:=c.Env(owner,repo,o.env,false);e!=nil{die(e.Error())}};var x []dotenv.Entry;if o.typ=="secret"{n,e:=c.ListSecrets(owner,repo,o.app,o.env);if e!=nil{die(e.Error())};for _,v:=range n{x=append(x,dotenv.Entry{Name:v})}}else{if o.org!=""{die("organization variable pull is not implemented yet")};v,e:=c.ListVariables(owner,repo,o.app,o.env);if e!=nil{die(e.Error())};for _,z:=range v{x=append(x,dotenv.Entry{Name:z[0],Value:z[1]})}};if e:=dotenv.WriteFile(o.file,x,o.typ=="secret");e!=nil{die(e.Error())};fmt.Printf("Pulled %d %s(s) to %s\n",len(x),o.typ,o.file)}
func split(s string)(string,string){p:=strings.SplitN(s,"/",2);if len(p)!=2{die("invalid repository: "+s)};return p[0],p[1]}
func need(a []string,i int,f string){if i>=len(a){die(f+" requires a value")}}
func die(s string){fmt.Fprintln(os.Stderr,"error:",s);os.Exit(1)}
func usage(){fmt.Println(`goenv v0.2.4

Usage:
  goenv push --repo OWNER/REPO --file FILE
  goenv push --repo OWNER/REPO --file FILE --type variable
  goenv push --repo OWNER/REPO --file FILE --env ENV
  goenv push --repo OWNER/REPO --file FILE --app actions|agents|codespaces|dependabot
  goenv push --org ORG --file FILE
  goenv pull --repo OWNER/REPO --file FILE
  goenv pull --repo OWNER/REPO --file FILE --type variable
  goenv pull --repo OWNER/REPO --file FILE --env ENV
  goenv version
  goenv help

Authentication: GITHUB_TOKEN or --token`)}
