# goenv

Current version: v0.2.4

Repository variables use GitHub's POST/PATCH API semantics; existing variables are updated and missing variables are created.

Release CI runs `go mod tidy` before cross-compilation so a clean GitHub runner has the required module checksums.

Cross-platform Go implementation of `ghenv`.

## Install

```bash
curl -fsSL https://raw.githubusercontent.com/komputeks/goenv/main/install.sh | bash
```

Then:

```bash
goenv version
```

The installer detects the host and selects the matching release.

## Commands

```bash
goenv push --repo OWNER/REPO --file /sdcard/secrets.env
goenv push --repo OWNER/REPO --file /sdcard/vars.env --type variable
goenv push --repo OWNER/REPO --file /sdcard/secrets.env --env production

goenv push --repo OWNER/REPO --file /sdcard/secrets.env --app actions
goenv push --repo OWNER/REPO --file /sdcard/secrets.env --app agents
goenv push --repo OWNER/REPO --file /sdcard/secrets.env --app codespaces
goenv push --repo OWNER/REPO --file /sdcard/secrets.env --app dependabot

goenv pull --repo OWNER/REPO --file /sdcard/secrets.env
goenv pull --repo OWNER/REPO --file /sdcard/vars.env --type variable
goenv pull --repo OWNER/REPO --file /sdcard/vars.env --type variable --force

goenv push --repo OWNER/REPO --file /sdcard/secrets.env --dry-run
```

If an environment does not exist, `push` creates it. `pull` never creates an environment.

## Authentication

Set `GITHUB_TOKEN`, or use `--token`.

The binary talks directly to GitHub and does not require `gh`.

## Release targets

Linux: amd64, arm64, armv7

Windows: amd64, arm64

macOS: amd64, arm64

Android: arm64, armv7, amd64, 386

Go lists all four Android architecture combinations as valid targets; Android builds that require external/cgo linking use the Android NDK in CI. citeturn0search0turn1search0

## Security

Secret values are encrypted locally with Libsodium sealed boxes before transmission. Secret pulls return names with empty values; plaintext secret values are not retrieved.

Never commit `.env` or `secrets.env`.

MIT License.
