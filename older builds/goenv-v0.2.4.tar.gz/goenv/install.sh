#!/usr/bin/env bash
set -euo pipefail
REPO="komputeks/goenv"; VERSION="${GOENV_VERSION:-latest}"
die(){ echo "error: $*" >&2; exit 1; }
command -v curl >/dev/null 2>&1 || die "curl is required"
OS="$(uname -s | tr '[:upper:]' '[:lower:]')"; A="$(uname -m)"
case "$OS" in linux) [ "${TERMUX_VERSION:-}" ] || [ "${PREFIX:-}" = "/data/data/com.termux/files/usr" ] && OS=android;; darwin) OS=darwin;; msys*|mingw*|cygwin*) OS=windows;; *) die "unsupported OS: $OS";; esac
case "$A" in x86_64|amd64) A=amd64;; aarch64|arm64) A=arm64;; armv7l|armv7|armhf) A=armv7;; i386|i686|x86) A=386;; *) die "unsupported architecture: $A";; esac
ASSET="goenv-$OS-$A"; [ "$OS" = windows ] && ASSET="$ASSET.exe"
if [ -n "${GOENV_INSTALL_DIR:-}" ];then DIR="$GOENV_INSTALL_DIR";elif [ "$OS" = android ]&&[ -n "${PREFIX:-}" ];then DIR="$PREFIX/bin";elif [ -w /usr/local/bin ]||[ "$(id -u)" -eq 0 ];then DIR=/usr/local/bin;else DIR="$HOME/.local/bin";fi
mkdir -p "$DIR"; TMP="$(mktemp)"; trap 'rm -f "$TMP"' EXIT
if [ "$VERSION" = latest ];then URL="https://github.com/$REPO/releases/latest/download/$ASSET";else URL="https://github.com/$REPO/releases/download/$VERSION/$ASSET";fi
echo "Installing goenv for $OS/$A...";curl -fsSL "$URL" -o "$TMP";install -m 0755 "$TMP" "$DIR/goenv${ASSET#goenv-$OS-$A}";"$DIR/goenv" version
