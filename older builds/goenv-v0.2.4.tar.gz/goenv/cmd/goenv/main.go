package main

import "github.com/komputeks/goenv/internal/cli"

func main() { cli.Run() }
